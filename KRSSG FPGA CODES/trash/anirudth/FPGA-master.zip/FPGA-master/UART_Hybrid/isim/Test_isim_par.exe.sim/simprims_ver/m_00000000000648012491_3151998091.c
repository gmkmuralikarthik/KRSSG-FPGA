/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_3292315892_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3292315892", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3292315892.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0896168481_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0896168481", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0896168481.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0787499929_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0787499929", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0787499929.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4264993156_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4264993156", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4264993156.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0015261608_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0015261608", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0015261608.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1796811868_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1796811868", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1796811868.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1138463624_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1138463624", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1138463624.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2688942073_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2688942073", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2688942073.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2609608528_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2609608528", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2609608528.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0651267415_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0651267415", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0651267415.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2290565165_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2290565165", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2290565165.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3985465074_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3985465074", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3985465074.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3561259681_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3561259681", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3561259681.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4035472970_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4035472970", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4035472970.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0521687300_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0521687300", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0521687300.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3853293628_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3853293628", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3853293628.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4137725761_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4137725761", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4137725761.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0502132496_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0502132496", "isim/Test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0502132496.didat");
}
